<head>
    <title>NecuFrame</title>

    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap-reboot.css">

    <script src="/assets/js/jquery.min.js/"></script>
    <script src="/assets/js/bootstrap.js/"></script>
</head>
