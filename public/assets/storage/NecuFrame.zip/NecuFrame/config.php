<?php

$config = [
    'DATABASE' => 'necu',
    'PASSWORD' => '',
    'HOST' => 'localhost',
    'USERNAME' => 'root',
    'PORT' => '3306'
];