# NecuFrame

1) composer install
2) go to public and start server (php -S 127.0.0.1:8000)
