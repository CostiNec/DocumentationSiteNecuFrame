<?php

function hello()
{
    echo 'Hello world!';
}