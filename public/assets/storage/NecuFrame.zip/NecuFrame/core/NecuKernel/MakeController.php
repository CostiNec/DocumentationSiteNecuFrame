<?php

namespace core\NecuKernel;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class MakeController extends Command
{
    protected $commandName = 'make:controller';
    protected $commandDescription = "Make a controller";

    protected $commandArgumentName = "name";
    protected $commandArgumentDescription = "Who do you want to greet?";

    protected $commandOptionName = "cap"; // should be specified like "app:greet John --cap"
    protected $commandOptionDescription = 'If set, it will greet in uppercase letters';

    protected function configure()
    {
        $this
            ->setName($this->commandName)
            ->setDescription($this->commandDescription)
            ->addArgument(
                $this->commandArgumentName,
                InputArgument::OPTIONAL,
                $this->commandArgumentDescription
            )
            ->addOption(
                $this->commandOptionName,
                null,
                InputOption::VALUE_NONE,
                $this->commandOptionDescription
            )
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $name = $input->getArgument($this->commandArgumentName);

        if ($name) {
            $text = "<?php

namespace controllers;

use core\Controller;
use core\Helper;

class " . $name . " extends Controller
{
    public function __construct(\$request)
    {
        parent::__construct(\$request);
    }
}";
        } else {
            $output->writeln('INSERT A CONTROLLER NAME');
        }

        if(file_exists('controllers/'.$name.'.php')) {
            $output->writeln('There is already a controller with this name :(');
        } else {
            file_put_contents('controllers/'.$name.'.php',$text);
            $output->writeln('The controller was successfully created!:)');
        }

    }
}