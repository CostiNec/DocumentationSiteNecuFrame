<?php
namespace models;

use core\Model;

/**
 * protected $primaryKey = 'ID';
 * const TABLE = 'table_name';(default is strtolower(model_name).'s' ex Example => examples
 */

class Example extends Model
{
    protected $columns = ['YOUR COLUMNS'];
}